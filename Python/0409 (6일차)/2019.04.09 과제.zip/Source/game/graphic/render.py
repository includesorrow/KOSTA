# -*- coding: utf-8 -*-

# /game/sound/echo.py


def render_test():
    print("render ~ !")
    