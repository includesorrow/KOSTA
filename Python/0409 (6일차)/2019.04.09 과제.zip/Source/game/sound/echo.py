# -*- coding: utf-8 -*-

# /game/sound/echo.py


def echo_test():
    print("echo print!")

    
def print_test():
    print("여기는 프린트테스트입니다")
    