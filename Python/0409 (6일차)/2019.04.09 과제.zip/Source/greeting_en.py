# -*- coding: utf-8 -*-
"""
greeting_en.py
Created on Tue Apr  9 09:44:28 2019

@author: daily
"""

def welcome():
    return "Hello"



