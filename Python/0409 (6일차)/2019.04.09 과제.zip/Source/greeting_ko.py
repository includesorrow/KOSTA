# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 09:48:15 2019

@author: daily
"""

def welcome():
    return "안녕하세요~"

