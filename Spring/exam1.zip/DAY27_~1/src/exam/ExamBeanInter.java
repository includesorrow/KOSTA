package exam;

public interface ExamBeanInter {
	
	public void callExecutebean(String condition);
	
	public String getMessageBean();
	
}
