package exam;

public interface ExamTypeInter {
	public String message();
}
