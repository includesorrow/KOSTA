package ex1.model;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DeptDao;
import ex1.controller.ModelForward;

public class DeptFindDnameModel implements ModelInter{

	@Override
	public ModelForward execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String dname = req.getParameter("dname");
		System.out.println("Dname=========>"+dname);
		int cnt = DeptDao.getDeptDao().findDname(dname);
		StringBuffer sb = new StringBuffer();
		if(cnt > 0) {
			sb.append("<p style='color:red'>");
			sb.append(dname).append("�� �̹� ��� ���� �μ����Դϴ�.</p>");
		}else {
			sb.append("<p style='color:blue'>");
			sb.append(dname).append("�� �̹� ��� ������ �μ����Դϴ�.</p>");
		}
		req.setAttribute("msg",sb.toString());
		return new ModelForward(true,"dnamefindAjax.jsp");
	}

}
