package collection;

import java.util.List;

public class Ex1_List {
	private List<String> items;
	private List<Float> itemsf;
	
	public List<String> getItems() {
		return items;
	}
	public void setItems(List<String> items) {
		this.items = items;
	}
	public List<Float> getItemsf() {
		return itemsf;
	}
	public void setItemsf(List<Float> itemsf) {
		this.itemsf = itemsf;
	}
}
