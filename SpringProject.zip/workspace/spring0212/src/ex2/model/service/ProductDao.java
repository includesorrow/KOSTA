package ex2.model.service;

import ex2.model.domain.ProductVO;

public interface ProductDao {
	public ProductVO getProduct();
}
