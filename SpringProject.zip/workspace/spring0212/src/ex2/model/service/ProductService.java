package ex2.model.service;

import ex2.model.domain.ProductVO;

public interface ProductService {
	public ProductVO getProduct();
}
