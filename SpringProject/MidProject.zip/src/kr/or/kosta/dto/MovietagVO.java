package kr.or.kosta.dto;

public class MovietagVO {

	private String movie_number, tag_table_num;
	private int tag_category_num;
	private String tag_name;
	private MovieVO movievo;
	private TagtableVO tagtablevo;
	
	public MovieVO getMovievo() {
		return movievo;
	}

	public void setMovievo(MovieVO movievo) {
		this.movievo = movievo;
	}

	public TagtableVO getTagtablevo() {
		return tagtablevo;
	}

	public void setTagtablevo(TagtableVO tagtablevo) {
		this.tagtablevo = tagtablevo;
	}

	public int getTag_category_num() {
		return tag_category_num;
	}

	public void setTag_category_num(int tag_category_num) {
		this.tag_category_num = tag_category_num;
	}

	public String getTag_name() {
		return tag_name;
	}

	public void setTag_name(String tag_name) {
		this.tag_name = tag_name;
	}

	public String getMovie_number() {
		return movie_number;
	}

	public void setMovie_number(String movie_number) {
		this.movie_number = movie_number;
	}

	public String getTag_table_num() {
		return tag_table_num;
	}

	public void setTag_table_num(String tag_table_num) {
		this.tag_table_num = tag_table_num;
	}
}
