package kr.or.kosta.dto;

public class ExcelVO {
	
	/*
	 * ����vo
	 */
	private String keyword;
	private int count;
	
	
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
}
