package kr.or.kosta.dto;

public class GM_AgeVO {
	private int age_10s, age_20s, age_30s, age_40s, age_50s, age_60s, age_70s, age_80s, age_90s;

	public int getAge_10s() {
		return age_10s;
	}

	public void setAge_10s(int age_10s) {
		this.age_10s = age_10s;
	}

	public int getAge_20s() {
		return age_20s;
	}

	public void setAge_20s(int age_20s) {
		this.age_20s = age_20s;
	}

	public int getAge_30s() {
		return age_30s;
	}

	public void setAge_30s(int age_30s) {
		this.age_30s = age_30s;
	}

	public int getAge_40s() {
		return age_40s;
	}

	public void setAge_40s(int age_40s) {
		this.age_40s = age_40s;
	}

	public int getAge_50s() {
		return age_50s;
	}

	public void setAge_50s(int age_50s) {
		this.age_50s = age_50s;
	}

	public int getAge_60s() {
		return age_60s;
	}

	public void setAge_60s(int age_60s) {
		this.age_60s = age_60s;
	}

	public int getAge_70s() {
		return age_70s;
	}

	public void setAge_70s(int age_70s) {
		this.age_70s = age_70s;
	}

	public int getAge_80s() {
		return age_80s;
	}

	public void setAge_80s(int age_80s) {
		this.age_80s = age_80s;
	}

	public int getAge_90s() {
		return age_90s;
	}

	public void setAge_90s(int age_90s) {
		this.age_90s = age_90s;
	}

}
