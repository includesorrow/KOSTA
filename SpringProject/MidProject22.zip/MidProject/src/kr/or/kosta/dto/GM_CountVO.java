package kr.or.kosta.dto;

public class GM_CountVO {
	private int movie_number_of_audience;
	private String movie_number;

	public int getMovie_number_of_audience() {
		return movie_number_of_audience;
	}

	public void setMovie_number_of_audience(int movie_number_of_audience) {
		this.movie_number_of_audience = movie_number_of_audience;
	}

	public String getMovie_number() {
		return movie_number;
	}

	public void setMovie_number(String movie_number) {
		this.movie_number = movie_number;
	}

}
