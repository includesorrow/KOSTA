package kr.or.kosta.dto;

public class GsbVO {
	
	
	private int rank_number;
	private String rank_name;
	
	public int getRank_number() {
		return rank_number;
	}
	public void setRank_number(int rank_number) {
		this.rank_number = rank_number;
	}
	public String getRank_name() {
		return rank_name;
	}
	public void setRank_name(String rank_name) {
		this.rank_name = rank_name;
	}


}
