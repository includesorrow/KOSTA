package kr.or.kosta.dto;


public class List_CategoryVO {
	
	private int list_category_number; 
	private String list_category_name;
	
	public int getList_category_number() {
		return list_category_number;
	}
	public void setList_category_number(int list_category_number) {
		this.list_category_number = list_category_number;
	}
	public String getList_category_name() {
		return list_category_name;
	}
	public void setList_category_name(String list_category_name) {
		this.list_category_name = list_category_name;
	}
	

}
