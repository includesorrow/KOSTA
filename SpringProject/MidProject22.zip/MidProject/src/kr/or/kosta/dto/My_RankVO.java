package kr.or.kosta.dto;

public class My_RankVO {
	
	
	private String member_number,movie_number,rank_number;

	public String getMember_number() {
		return member_number;
	}

	public void setMember_number(String member_number) {
		this.member_number = member_number;
	}

	public String getMovie_number() {
		return movie_number;
	}

	public void setMovie_number(String movie_number) {
		this.movie_number = movie_number;
	}

	public String getRank_number() {
		return rank_number;
	}

	public void setRank_number(String rank_number) {
		this.rank_number = rank_number;
	}

}
