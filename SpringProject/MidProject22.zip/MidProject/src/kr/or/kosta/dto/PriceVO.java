package kr.or.kosta.dto;

public class PriceVO {
	private int movie_real_price,movie_price;

	public int getMovie_real_price() {
		return movie_real_price;
	}

	public void setMovie_real_price(int movie_real_price) {
		this.movie_real_price = movie_real_price;
	}

	public int getMovie_price() {
		return movie_price;
	}

	public void setMovie_price(int movie_price) {
		this.movie_price = movie_price;
	}
	
}
