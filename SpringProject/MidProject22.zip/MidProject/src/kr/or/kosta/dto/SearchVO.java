package kr.or.kosta.dto;

public class SearchVO {
	private String selectsearch,search;

	public String getSelectsearch() {
		return selectsearch;
	}

	public void setSelectsearch(String selectsearch) {
		this.selectsearch = selectsearch;
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

}
