package kr.or.kosta.dto;

public class Tag_CategoryVO {
    private String tag_category_name;
    private int tag_category_num;
    public String getTag_category_name() {
        return tag_category_name;
    }
    public void setTag_category_name(String tag_category_name) {
        this.tag_category_name = tag_category_name;
    }
    public int getTag_category_num() {
        return tag_category_num;
    }
    public void setTag_category_num(int tag_category_num) {
        this.tag_category_num = tag_category_num;
    }
}