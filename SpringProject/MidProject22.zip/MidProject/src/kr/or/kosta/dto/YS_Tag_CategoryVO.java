package kr.or.kosta.dto;

public class YS_Tag_CategoryVO {
	private int tag_Category_Num;
	private String tag_Category_Name;
	
	public int getTag_Category_Num() {
		return tag_Category_Num;
	}
	public void setTag_Category_Num(int tag_Category_Num) {
		this.tag_Category_Num = tag_Category_Num;
	}
	public String getTag_Category_Name() {
		return tag_Category_Name;
	}
	public void setTag_Category_Name(String tag_Category_Name) {
		this.tag_Category_Name = tag_Category_Name;
	}

}
