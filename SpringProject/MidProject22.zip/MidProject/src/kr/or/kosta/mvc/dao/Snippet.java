package kr.or.kosta.mvc.dao;

public class Snippet {
	public static void main(String[] args) {
		
	}
}

